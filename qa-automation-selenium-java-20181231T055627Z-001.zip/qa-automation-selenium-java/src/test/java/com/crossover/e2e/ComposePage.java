package com.crossover.e2e;

public class ComposePage extends TestBase {

	public ComposePage() {
		// TODO Auto-generated constructor stub
		
		
	}

}
