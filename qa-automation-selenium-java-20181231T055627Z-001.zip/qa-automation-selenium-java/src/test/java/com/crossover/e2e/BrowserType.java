package com.crossover.e2e;

public enum BrowserType {
	Firefox,
	Iexplorer,
	PhantomJs,
	HtmlUnitDriver,
	Chrome
}
